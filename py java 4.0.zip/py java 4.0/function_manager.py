from math_engine import PyJavaMathEngine

class PyJavaFunctionEngine:
    """
    Function Manager Engine for PyJava Language Architecture.
    Handles function declaration, argument mapping, and return execution.
    """
    def __init__(self, math_engine: PyJavaMathEngine):
        self.math_engine = math_engine
        self.functions = {}

    def declare_function(self, func_name, param_list, body_statements):
        """
        Registers a new function definition in PyJava runtime.
        """
        self.functions[func_name] = {
            "params": param_list,
            "body": body_statements
        }
        return f"Function '{func_name}' declared successfully."

    def call_function(self, func_name, *args):
        """
        Executes a registered PyJava function with local argument bindings.
        """
        if func_name not in self.functions:
            raise NameError(f"PyJava Runtime Error: Function '{func_name}' is not defined.")

        func_data = self.functions[func_name]
        params = func_data["params"]
        body = func_data["body"]

        if len(params) != len(args):
            raise TypeError(
                f"PyJava Argument Error: '{func_name}' expects {len(params)} arguments, got {len(args)}."
            )

        # Temporary scope backup for parameter isolation
        backup_vars = self.math_engine.variables.copy()

        # Bind parameters to arguments
        for param_name, arg_val in zip(params, args):
            evaluated_arg = self.math_engine._resolve_val(arg_val)
            self.math_engine.set_variable(param_name, evaluated_arg)

        return_value = None
        try:
            for statement in body:
                if isinstance(statement, str) and statement.startswith("return "):
                    expr = statement.replace("return ", "").strip()
                    return_value = self.math_engine.execute_advanced_op(expr)
                    break
                else:
                    self.math_engine.execute_advanced_op(statement)
        finally:
            # Restore variable scope after execution
            self.math_engine.variables = backup_vars

        return return_value


if __name__ == "__main__":
    math_core = PyJavaMathEngine()
    func_engine = PyJavaFunctionEngine(math_core)

    print("--- PyJava Function Manager Test ---")

    # Declare a test function: func calculate_hypotenuse(a, b)
    func_engine.declare_function(
        func_name="calculate_hypotenuse",
        param_list=["a", "b"],
        body_statements=[
            "return sqrt(a**2 + b**2)"
        ]
    )

    # Call function with parameters (3, 4) -> should return 5.0
    result = func_engine.call_function("calculate_hypotenuse", 3, 4)
    print(f"Function Output (3, 4): {result}")
