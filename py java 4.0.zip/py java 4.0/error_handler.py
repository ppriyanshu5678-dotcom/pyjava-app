import sys

class PyJavaErrorHandler:
    """
    Smart Diagnostics & Error Handling Engine for PyJava.
    Formats exact line numbers, syntax suggestions, and stack tracebacks.
    """
    def __init__(self, filename="<main.pj>"):
        self.filename = filename

    def raise_syntax_error(self, message, line_num, snippet=""):
        print(f"\n[ PyJava Syntax Error ]")
        print(f"  File '{self.filename}', line {line_num}")
        if snippet:
            print(f"    {snippet.strip()}")
        print(f"SyntaxError: {message}\n")

    def raise_runtime_error(self, error_type, message, line_num=None):
        print(f"\n[ PyJava Runtime Exception ]")
        if line_num:
            print(f"  File '{self.filename}', line {line_num}")
        print(f"{error_type}: {message}\n")

    def wrap_execution(self, func, *args, **kwargs):
        """Wraps unsafe execution with PyJava crash protection."""
        try:
            return func(*args, **kwargs)
        except ZeroDivisionError:
            self.raise_runtime_error("ZeroDivisionError", "Division by zero is undefined.")
        except NameError as e:
            self.raise_runtime_error("NameError", str(e))
        except Exception as e:
            self.raise_runtime_error("ExecutionError", str(e))


if __name__ == "__main__":
    handler = PyJavaErrorHandler("test_script.pj")

    print("--- PyJava Error Handler Test ---")
    
    # Test 1: Syntax Error formatting
    handler.raise_syntax_error("Missing closing parenthesis ')'", line_num=4, snippet="func calc(a, b")

    # Test 2: Runtime Crash Protection
    def faulty_operation():
        return 10 / 0

    handler.wrap_execution(faulty_operation)
