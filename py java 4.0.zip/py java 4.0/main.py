# main.py - PyJava Execution Entry Point

import sys
# Core Engine classes import kar rahe hain
from pyjava_core import (
    Lexer, Parser, Evaluator, RuntimeContext, 
    SymbolTable, PyJavaError
)

def run_pyjava(source_code: str):
    """PyJava Source Code ko Lex, Parse aur Execute karne ka Runner function"""
    print("=" * 50)
    print("⚡ RUNNING PYJAVA PROGRAM ⚡")
    print("=" * 50)
    
    try:
        # 1. Lexical Analysis (Tokens generation)
        lexer = Lexer(source_code)
        tokens = lexer.make_tokens()
        
        # 2. Parsing (AST Build karna)
        parser = Parser(tokens)
        ast_tree = parser.parse()
        
        if not ast_tree:
            print("⚠️ Parsing failed: No AST generated.")
            return

        # 3. Environment & Evaluation Setup
        global_symbol_table = SymbolTable()
        context = RuntimeContext("<main_script>", global_symbol_table)
        evaluator = Evaluator(context)
        
        # 4. AST Tree Execution
        result = evaluator.visit(ast_tree)
        
        print("\n" + "=" * 50)
        print("✅ EXECUTION SUCCESSFUL")
        print("=" * 50)
        if result is not None:
            print(f"Final Return Value: {result}")
            
    except PyJavaError as e:
        # PyJava Custom Error Handling
        print(f"\n❌ RUNTIME ERROR: {e}")
    except Exception as e:
        # Python Native Crash Safety
        print(f"\n💥 SYSTEM UNHANDLED ERROR: {e}")

# =====================================================================
# TEST SCRIPT (Yahan apna test code do)
# =====================================================================

if __name__ == "__main__":
    # Test PyJava Source Code
    test_code = """
    // PyJava Test Program
    x = 10;
    y = 20;
    sum = x + y;
    print(sum);
    """
    
    run_pyjava(test_code)
