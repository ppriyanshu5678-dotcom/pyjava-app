from math_engine import PyJavaMathEngine

class PyJavaControlFlowEngine:
    """
    Core Control Flow & Loop Engine for PyJava Language Architecture.
    Handles Conditional Logic (if/elif/else) and Execution Blocks.
    """
    def __init__(self, math_engine: PyJavaMathEngine):
        self.math_engine = math_engine

    def evaluate_condition(self, condition_str):
        try:
            res = self.math_engine.execute_advanced_op(condition_str)
            return bool(res)
        except Exception as e:
            raise SyntaxError(f"PyJava Condition Error: Invalid logic '{condition_str}' -> {str(e)}")

    def execute_if_block(self, conditions_and_blocks):
        for condition, block in conditions_and_blocks:
            if condition == "else" or self.evaluate_condition(condition):
                return self._run_block(block)
        return None

    def execute_while_loop(self, condition_str, block, max_iterations=100000):
        iterations = 0
        results = []
        while self.evaluate_condition(condition_str):
            if iterations >= max_iterations:
                raise RuntimeWarning("PyJava Memory Shield: Execution stopped (Infinite Loop Detected).")
            res = self._run_block(block)
            results.append(res)
            iterations += 1
        return results

    def _run_block(self, block):
        if callable(block):
            return block()
        return self.math_engine.execute_advanced_op(str(block))


if __name__ == "__main__":
    # Clean Test Bench
    math_core = PyJavaMathEngine()
    math_core.set_variable("counter", 0)
    math_core.set_variable("limit", 5)

    flow_engine = PyJavaControlFlowEngine(math_core)

    print("--- PyJava Control Flow Test ---")

    # 1. If-Else Test
    condition_chain = [
        ("counter > 10", "'Counter is High'"),
        ("counter == 0", "'Counter is Zero (Matched)'"),
        ("else", "'Default Block'")
    ]
    if_result = flow_engine.execute_if_block(condition_chain)
    print(f"If-Else Output: {if_result}")

    # 2. While Loop Test
    def loop_body():
        current = math_core.get_variable("counter")
        math_core.set_variable("counter", current + 1)
        return f"Iteration {current + 1}"

    loop_output = flow_engine.execute_while_loop("counter < limit", loop_body)
    print(f"Loop Executions: {loop_output}")
    print(f"Final Counter Value: {math_core.get_variable('counter')}")
