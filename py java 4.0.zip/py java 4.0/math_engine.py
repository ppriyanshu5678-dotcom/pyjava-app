import math
import cmath

class PyJavaMathEngine:
    """
    Supercharged High-Precision Dynamic Math & Variable Engine for PyJava.
    Supports Scalar, Complex, Vectors, and Inline Dynamic Expressions.
    """
    def __init__(self):
        self.variables = {}
        
    def set_variable(self, name, val):
        self.variables[name] = val
        return val

    def get_variable(self, name):
        if name in self.variables:
            return self._resolve_val(self.variables[name])
        raise NameError(f"PyJava Engine Error: Variable '{name}' is undefined.")

    def _get_base_context(self):
        return {
            "sin": math.sin, "cos": math.cos, "tan": math.tan,
            "sqrt": math.sqrt, "log": math.log, "pi": math.pi, "e": math.e,
            "csqrt": cmath.sqrt, "cphase": cmath.phase,
            "fact": math.factorial, "pow": math.pow,
            "dot": lambda v1, v2: sum(x * y for x, y in zip(v1, v2)),
            "mag": lambda v: math.sqrt(sum(x**2 for x in v))
        }

    def _resolve_val(self, value):
        if isinstance(value, (int, float, complex, list)):
            return value
        if isinstance(value, str):
            ctx = self._get_base_context()
            for k, v in self.variables.items():
                if k not in ctx:
                    ctx[k] = self._resolve_val(v) if isinstance(v, str) and v != value else v
            try:
                return eval(value, {"__builtins__": None}, ctx)
            except Exception:
                return value
        return value

    def execute_advanced_op(self, expression):
        ctx = self._get_base_context()
        for k, v in self.variables.items():
            ctx[k] = self._resolve_val(v)
        try:
            return eval(expression, {"__builtins__": None}, ctx)
        except Exception as e:
            return f"PyJava Execution Error: {str(e)}"

# Clean Test Bench (Runs only when executing math_engine.py directly)
if __name__ == "__main__":
    pyjava = PyJavaMathEngine()
    pyjava.set_variable("alpha", "100 ** 2 + sqrt(144)")
    pyjava.set_variable("vecA", [3, 4, 12])
    pyjava.set_variable("vecB", [1, 2, 3])

    res_vector = pyjava.execute_advanced_op("dot(vecA, vecB) + mag(vecA)")
    res_complex = pyjava.execute_advanced_op("csqrt(-16) + sin(pi / 2) * alpha")

    print("--- PyJava Math Engine Test ---")
    print(f"Vector Result: {res_vector}")
    print(f"Complex Math Result: {res_complex}")
