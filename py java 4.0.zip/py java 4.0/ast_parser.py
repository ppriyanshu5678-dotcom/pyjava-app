from lexer_engine import PyJavaLexerEngine, PyJavaToken

class ASTNode:
    def __init__(self, type_, value=None, children=None):
        self.type = type_
        self.value = value
        self.children = children if children else []

    def __repr__(self):
        return f"ASTNode({self.type}, val={self.value}, children={len(self.children)})"

class PyJavaASTParser:
    """
    Abstract Syntax Tree (AST) Parser for PyJava Language Architecture.
    Converts token streams into structured execution trees.
    """
    def __init__(self):
        self.tokens = []
        self.pos = 0

    def parse(self, tokens):
        self.tokens = tokens
        self.pos = 0
        nodes = []
        while self.pos < len(self.tokens):
            node = self._parse_statement()
            if node:
                nodes.append(node)
        return ASTNode("PROGRAM", children=nodes)

    def _peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def _advance(self):
        tok = self._peek()
        self.pos += 1
        return tok

    def _parse_statement(self):
        tok = self._peek()
        if not tok:
            return None

        if tok.type == "KEYWORD" and tok.value == "func":
            return self._parse_function_decl()
        elif tok.type == "KEYWORD" and tok.value == "if":
            return self._parse_if_stmt()
        elif tok.type == "KEYWORD" and tok.value == "return":
            self._advance()
            expr = self._advance()
            return ASTNode("RETURN_STMT", value=expr.value if expr else None)
        else:
            self._advance()
            return ASTNode("EXPRESSION", value=tok.value)

    def _parse_function_decl(self):
        self._advance()  # Skip 'func'
        name_tok = self._advance()
        self._advance()  # Skip '('
        params = []
        while self._peek() and self._peek().type != "RPAREN":
            p = self._advance()
            if p.type == "IDENT":
                params.append(p.value)
            elif p.type == "COMMA":
                continue
        self._advance()  # Skip ')'
        if self._peek() and self._peek().type == "COLON":
            self._advance()  # Skip ':'

        return ASTNode("FUNC_DECL", value=name_tok.value, children=[ASTNode("PARAMS", value=params)])

    def _parse_if_stmt(self):
        self._advance()  # Skip 'if'
        cond_tok = self._advance()
        if self._peek() and self._peek().type == "COLON":
            self._advance()
        return ASTNode("IF_STMT", value=cond_tok.value)


if __name__ == "__main__":
    lexer = PyJavaLexerEngine()
    parser = PyJavaASTParser()

    code = """
    func add(a, b):
        return a
    """

    print("--- PyJava AST Parser Test ---")
    tokens = lexer.tokenize(code)
    ast_tree = parser.parse(tokens)
    print(f"Root Node: {ast_tree}")
    for child in ast_tree.children:
        print(f"  └─ {child}")
