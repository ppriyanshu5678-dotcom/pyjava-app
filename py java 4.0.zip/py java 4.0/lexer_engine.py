import re

class PyJavaToken:
    def __init__(self, type_, value, line):
        self.type = type_
        self.value = value
        self.line = line

    def __repr__(self):
        return f"Token({self.type}, '{self.value}', Line:{self.line})"

class PyJavaLexerEngine:
    """
    High-Speed Lexer & Tokenizer Engine for PyJava Language.
    Converts raw source code into structured tokens.
    """
    TOKEN_SPEC = [
        ('NUMBER',   r'\d+(\.\d+)?'),
        ('STRING',   r'"[^"]*"|\'[^\']*\''),
        ('KEYWORD',  r'\b(if|else|elif|while|for|def|func|return|import|print)\b'),
        ('IDENT',    r'[a-zA-Z_][a-zA-Z0-9_]*'),
        ('OP',       r'==|!=|<=|>=|\+|\-|\*|/|%|=|>|<'),
        ('LPAREN',   r'\('),
        ('RPAREN',   r'\)'),
        ('LBRACE',   r'\{'),
        ('RBRACE',   r'\}'),
        ('COMMA',    r','),
        ('COLON',    r':'),
        ('NEWLINE',  r'\n'),
        ('SKIP',     r'[ \t]+'),
        ('MISMATCH', r'.'),
    ]

    def tokenize(self, code):
        tok_regex = '|'.join(f'(?P<{pair[0]}>{pair[1]})' for pair in self.TOKEN_SPEC)
        line_num = 1
        tokens = []

        for mo in re.finditer(tok_regex, code):
            kind = mo.lastgroup
            value = mo.group()

            if kind == 'NUMBER':
                value = float(value) if '.' in value else int(value)
                tokens.append(PyJavaToken(kind, value, line_num))
            elif kind == 'STRING':
                tokens.append(PyJavaToken(kind, value[1:-1], line_num))
            elif kind in ('KEYWORD', 'IDENT', 'OP', 'LPAREN', 'RPAREN', 'LBRACE', 'RBRACE', 'COMMA', 'COLON'):
                tokens.append(PyJavaToken(kind, value, line_num))
            elif kind == 'NEWLINE':
                line_num += 1
            elif kind == 'SKIP':
                continue
            elif kind == 'MISMATCH':
                raise SyntaxError(f"PyJava Lexer Error: Unexpected character '{value}' on line {line_num}")

        return tokens


if __name__ == "__main__":
    lexer = PyJavaLexerEngine()
    
    sample_code = """
    func calc(a, b):
        if a > 10:
            return a + b
        return 0
    """
    
    print("--- PyJava Lexer Engine Test ---")
    tokens = lexer.tokenize(sample_code)
    for tok in tokens:
        print(tok)
