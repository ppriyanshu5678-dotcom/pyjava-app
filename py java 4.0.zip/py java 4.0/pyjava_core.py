# ==========================================
# UPDATED MASTER RUNTIME ENGINE WITH EVALUATOR
# ==========================================
class PyJavaMasterRuntime:
    def __init__(self, filename="main.pj"):
        self.math_engine = PyJavaMathEngine()
        self.scope = PyJavaScopeEngine(self.math_engine)
        self.flow = PyJavaControlFlowEngine(self.math_engine)
        self.functions = PyJavaFunctionEngine(self.math_engine)
        self.lexer = PyJavaLexerEngine()
        self.parser = PyJavaASTParser()
        self.error_handler = PyJavaErrorHandler(filename)

    def evaluate_ast(self, node):
        """Recursively evaluates PyJava AST nodes and executes operations."""
        if not node:
            return None

        if node.type == "PROGRAM":
            results = []
            for child in node.children:
                res = self.evaluate_ast(child)
                if res is not None:
                    results.append(res)
            return results[-1] if results else None

        elif node.type == "FUNC_DECL":
            func_name = node.value
            params = node.children[0].value if node.children else []
            body = node.children[1:] if len(node.children) > 1 else []
            
            # Register function inside function manager
            self.functions.declare_function(func_name, params, body)
            return f"[PyJava] Function '{func_name}' registered successfully."

        elif node.type == "RETURN_STMT":
            return self.math_engine.execute_advanced_op(str(node.value))

        elif node.type == "EXPRESSION":
            return self.math_engine.execute_advanced_op(str(node.value))

        return None

    def run_code(self, source_code):
        def _execute():
            tokens = self.lexer.tokenize(source_code)
            ast = self.parser.parse(tokens)
            
            # Line by line direct math evaluation fallback
            lines = [line.strip() for line in source_code.split("\n") if line.strip()]
            final_output = None
            for line in lines:
                if not line.startswith("func") and not line.startswith("return"):
                    final_output = self.math_engine.execute_advanced_op(line)

            return final_output if final_output is not None else "Execution completed."

        return self.error_handler.wrap_execution(_execute)


if __name__ == "__main__":
    runtime = PyJavaMasterRuntime("test.pj")
    
    try:
        with open("test.pj", "r") as f:
            code = f.read()
        print("--- PyJava Execution Output ---")
        output = runtime.run_code(code)
        print(f"Output: {output}")
    except FileNotFoundError:
        print("Error: 'test.pj' file nahi mili!")
