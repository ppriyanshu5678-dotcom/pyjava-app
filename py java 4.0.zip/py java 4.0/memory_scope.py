from math_engine import PyJavaMathEngine

class PyJavaScopeEngine:
    """
    Scope & Memory Frame Architecture for PyJava.
    Manages Local vs Global Scope, Stack Frames, and Variable Isolation.
    """
    def __init__(self, math_engine: PyJavaMathEngine):
        self.math_engine = math_engine
        self.global_scope = {}
        self.call_stack = []

    def push_frame(self, frame_name="local_frame"):
        """Creates a new isolated stack frame for functions/blocks."""
        frame = {
            "name": frame_name,
            "local_vars": {}
        }
        self.call_stack.append(frame)

    def pop_frame(self):
        """Removes current frame after block execution."""
        if self.call_stack:
            return self.call_stack.pop()
        raise IndexError("PyJava Memory Error: Stack Underflow.")

    def set_var(self, name, val):
        """Sets variable in the active local frame if available, else in global scope."""
        resolved_val = self.math_engine._resolve_val(val)
        if self.call_stack:
            self.call_stack[-1]["local_vars"][name] = resolved_val
        else:
            self.global_scope[name] = resolved_val
        self.math_engine.variables[name] = resolved_val
        return resolved_val

    def get_var(self, name):
        """Searches variable from local stack frame first, then global scope."""
        if self.call_stack and name in self.call_stack[-1]["local_vars"]:
            return self.call_stack[-1]["local_vars"][name]
        if name in self.global_scope:
            return self.global_scope[name]
        return self.math_engine.get_variable(name)

    def sync_to_math_engine(self):
        """Combines current frame and global scope to keep math engine updated."""
        combined = self.global_scope.copy()
        if self.call_stack:
            combined.update(self.call_stack[-1]["local_vars"])
        self.math_engine.variables = combined


if __name__ == "__main__":
    math_core = PyJavaMathEngine()
    scope_mgr = PyJavaScopeEngine(math_core)

    print("--- PyJava Memory Scope Test ---")
    
    # Global Scope Set
    scope_mgr.set_var("x", 100)
    print(f"Global x: {scope_mgr.get_var('x')}")

    # Enter Local Scope Frame
    scope_mgr.push_frame("my_function_frame")
    scope_mgr.set_var("x", 20)  # Local shadow copy
    scope_mgr.set_var("y", 50)
    print(f"Local x (inside frame): {scope_mgr.get_var('x')}")
    print(f"Local y (inside frame): {scope_mgr.get_var('y')}")

    # Exit Scope Frame
    scope_mgr.pop_frame()
    print(f"Global x (after frame exit): {scope_mgr.get_var('x')}")
